# The fly visual-system map (connectome)

`fib25-fib19_v2.2.json` is the wiring map the project's model is built from: flyvis's own connectome file,
copied unchanged from the official flyvis 1.2.0 package on PyPI (`flyvis/connectome/fib25-fib19_v2.2.json`).

It describes the motion-vision pathway of the fruit fly's optic lobe: 65 cell types, which types connect, the sign
of each connection, and the average synapse count at each column offset. It was built by the flyvis authors from
two electron-microscopy reconstructions (FIB-25 and FIB-19), averaged into one typical column. It is not the
whole-brain FlyWire map.

`flyeye.py` turns it into the full model by repeating that column across the eye's 721 columns: 45,669 neurons and
1,513,231 connections, matching flyvis's published counts.

```python
import json, flyeye
lat = flyeye.build_lattice(json.load(open("connectome/fib25-fib19_v2.2.json")))
```

## Proof it is the official file

SHA-256: `bfbb0766251ff09e22723d0ebbf7b14793e70b3ae8ad0eea64eac9d28223351a`

This matches the checksum flyvis 1.2.0 records for the file in its own package manifest. To check it yourself:

```bash
sha256sum fib25-fib19_v2.2.json          # macOS: shasum -a 256 fib25-fib19_v2.2.json
```

## Licence

flyvis is MIT-licensed (Lappalainen, Tschopp, McGill, Macke, Turaga, 2023); its notice is in `LICENSE-flyvis.txt`
and must stay with the file. Paper: Lappalainen et al., "Connectome-constrained networks predict neural activity
across the fly visual system", Nature 634, 1132-1140 (2024).
